/* ── i18n strings ────────────────────────────────────────── */
const strings = {
  en: {
    'lang-toggle':  'EN ↔ 한글',
    't-title':      'Eco Sort',
    't-sub':        'Learn to Sort, Grow to Bloom',
    't-start':      'Start Game',
    't-lb':         'Leaderboard',
    't-htp':        'How to Play',
    't-lb-title':   'Leaderboard',
    't-htp-title':  'How to Play',
    't-h1':         'Sort the waste',
    't-h1d':        'Drag each item into the correct bin — recyclables, compost, landfill, or hazardous.',
    't-h2':         'Drag & drop',
    't-h2d':        'Grab items and drop them into the matching bin. On mobile, tap and hold then drag.',
    't-h3':         'Blossom lifeline',
    't-h3d':        'Each mistake wilts a petal. Three petals lost and the round ends — keep your garden blooming!',
    't-h4':         'Earn points',
    't-h4d':        'Correct sorts add to your score. Combos and speed bonuses help you climb the leaderboard.',
    't-htp-start':  'Let\'s Play! 🌿',
    'd-easy':       'Easy',
    'd-medium':     'Medium',
    'd-hard':       'Hard',
    'lb-empty-h':   'No scores yet!',
    'lb-empty-p':   'Play your first round and your score will appear here.',
    'lb-play-now':  'Play now',
  },
  ko: {
    'lang-toggle':  '한글 ↔ EN',
    't-title':      'Eco Sort',
    't-sub':        '분류하고 꽃을 피워요',
    't-start':      '게임 시작',
    't-lb':         '리더보드',
    't-htp':        '게임 방법',
    't-lb-title':   '리더보드',
    't-htp-title':  '게임 방법',
    't-h1':         '쓰레기 분류',
    't-h1d':        '각 아이템을 올바른 통에 넣으세요 — 재활용, 퇴비, 일반, 유해 폐기물.',
    't-h2':         '드래그 & 드롭',
    't-h2d':        '아이템을 잡아 알맞은 통에 놓으세요. 모바일에서는 길게 누른 후 드래그하세요.',
    't-h3':         '꽃잎 생명선',
    't-h3d':        '실수할 때마다 꽃잎이 시들어요. 꽃잎 세 개를 잃으면 라운드가 끝납니다!',
    't-h4':         '점수 획득',
    't-h4d':        '올바른 분류로 점수를 쌓고, 연속 정답과 속도 보너스로 리더보드를 오르세요.',
    't-htp-start':  '시작해볼까요! 🌿',
    'd-easy':       '쉬움',
    'd-medium':     '보통',
    'd-hard':       '어려움',
    'lb-empty-h':   '아직 점수가 없어요!',
    'lb-empty-p':   '첫 번째 게임을 플레이하면 여기에 점수가 표시됩니다.',
    'lb-play-now':  '지금 플레이',
  }
};

/* ── State ───────────────────────────────────────────────── */
// Audit fix: persist language preference
let lang = localStorage.getItem('ecosort-lang') || 'en';
let difficulty = localStorage.getItem('ecosort-diff') || 'easy';
let audioCtx = null;

/* ── Apply saved difficulty on load ──────────────────────── */
function initDifficulty() {
  document.querySelectorAll('.diff-pill').forEach(p => p.classList.remove('active'));
  const active = document.querySelector(`.diff-pill[data-diff="${difficulty}"]`);
  if (active) active.classList.add('active');
}

/* ── Language ────────────────────────────────────────────── */
function applyLang() {
  const s = strings[lang];
  Object.keys(s).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = s[id];
  });
  document.documentElement.lang = lang === 'ko' ? 'ko' : 'en';
}
function toggleLang() {
  lang = lang === 'en' ? 'ko' : 'en';
  localStorage.setItem('ecosort-lang', lang); // audit fix: persist
  applyLang();
  playTap();
}

/* ── Difficulty ──────────────────────────────────────────── */
function setDiff(el) {
  document.querySelectorAll('.diff-pill').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  difficulty = el.dataset.diff;
  localStorage.setItem('ecosort-diff', difficulty); // persist
  playTap();
}

/* ── Audio (audit fix: init on gesture, graceful degrade) ── */
function initAudio() {
  if (audioCtx) return;
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  } catch(e) { audioCtx = null; }
}
function playTap() {
  initAudio();
  if (!audioCtx) return;
  try {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.type = 'sine';
    o.frequency.setValueAtTime(520, audioCtx.currentTime);
    o.frequency.exponentialRampToValueAtTime(320, audioCtx.currentTime + .08);
    g.gain.setValueAtTime(.18, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + .12);
    o.start(); o.stop(audioCtx.currentTime + .13);
  } catch(e) {}
}

/* ── Ripple ──────────────────────────────────────────────── */
function addRipple(btn, e) {
  const r = btn.getBoundingClientRect();
  const size = Math.max(r.width, r.height);
  const x = (e.clientX - r.left) - size / 2;
  const y = (e.clientY - r.top)  - size / 2;
  const circle = document.createElement('span');
  circle.className = 'ripple-circle';
  circle.style.cssText = `width:${size}px;height:${size}px;left:${x}px;top:${y}px`;
  btn.appendChild(circle);
  setTimeout(() => circle.remove(), 600);
}
document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', e => { addRipple(btn, e); playTap(); });
});

/* ── Navigation ──────────────────────────────────────────── */
function startGame(btn) {
  // In a real implementation, pass difficulty to the game screen
  console.log('Starting game — difficulty:', difficulty);
  // Replace this with your actual screen transition:
  // showScreen('screen-game');
}

function startFromTutorial(btn) {
  closeOverlay('overlay-htp');
  setTimeout(() => startGame(btn), 350);
}

function openLeaderboard() {
  renderLeaderboard();
  openOverlay('overlay-lb');
}

function openHowToPlay() {
  openOverlay('overlay-htp');
}

function openOverlay(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeOverlay(id, e) {
  // Close on backdrop click (not panel click)
  if (e && e.target !== document.getElementById(id)) return;
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}

// Keyboard: Escape closes overlays
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    ['overlay-lb','overlay-htp'].forEach(id => {
      document.getElementById(id).classList.remove('open');
    });
    document.body.style.overflow = '';
  }
});

/* ── Leaderboard render (audit fix: empty state) ─────────── */
function renderLeaderboard() {
  const s = strings[lang];
  const scores = JSON.parse(localStorage.getItem('ecosort-scores') || '[]');
  const container = document.getElementById('lb-content');

  if (scores.length === 0) {
    container.innerHTML = `
      <div class="lb-empty">
        <span class="lb-emoji">🌱</span>
        <p><strong>${s['lb-empty-h']}</strong><br>${s['lb-empty-p']}</p>
        <button class="btn btn-primary" style="margin-top:20px" onclick="closeOverlay('overlay-lb');setTimeout(startGame,350)">
          ${s['lb-play-now']}
        </button>
      </div>`;
    return;
  }

  const ranks = ['gold','silver','bronze'];
  container.innerHTML = `<ul class="lb-list">
    ${scores.slice(0,10).map((entry, i) => `
      <li class="lb-row">
        <div class="lb-rank ${ranks[i]||''}">${i+1}</div>
        <span class="lb-name">${entry.name || 'Player'}</span>
        <span class="lb-score">${entry.score.toLocaleString()}</span>
      </li>`).join('')}
  </ul>`;
}

/* ── Petal animation ─────────────────────────────────────── */
const canvas = document.getElementById('petal-canvas');
const ctx    = canvas.getContext('2d');
const PETAL_COUNT = 22;
const petals = [];

function resize() {
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize);
resize();

const COLORS = ['#F8BBD0','#FCE4EC','#F48FB1','#FFB7C5','#FADADD'];

function makePetal() {
  return {
    x:     Math.random() * canvas.width,
    y:     -20 - Math.random() * 80,
    size:  6 + Math.random() * 8,
    speed: .5 + Math.random() * .9,
    drift: (Math.random() - .5) * .6,
    rot:   Math.random() * Math.PI * 2,
    rotV:  (Math.random() - .5) * .03,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    sway:  Math.random() * Math.PI * 2,
    swayS: .008 + Math.random() * .012,
  };
}

for (let i = 0; i < PETAL_COUNT; i++) {
  const p = makePetal();
  p.y = Math.random() * canvas.height; // seed across screen
  petals.push(p);
}

function drawPetal(p) {
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.rot);
  ctx.fillStyle = p.color;
  ctx.globalAlpha = .75;
  ctx.beginPath();
  ctx.ellipse(0, 0, p.size, p.size * .55, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function animatePetals() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  petals.forEach(p => {
    p.sway += p.swayS;
    p.x += p.drift + Math.sin(p.sway) * .5;
    p.y += p.speed;
    p.rot += p.rotV;
    if (p.y > canvas.height + 20) {
      Object.assign(p, makePetal());
      p.y = -20;
    }
    drawPetal(p);
  });
  requestAnimationFrame(animatePetals);
}
animatePetals();

/* ── Boot ────────────────────────────────────────────────── */
applyLang();
initDifficulty();

const bgMusic = document.getElementById("bgMusic");

bgMusic.volume = 0.3;

document.addEventListener("click", () => {
    bgMusic.play();
}, { once: true });