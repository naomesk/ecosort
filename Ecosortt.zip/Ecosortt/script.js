function playAgain(){

    alert("Restarting Eco Sort...");

    // Replace later:
    // window.location.href = "game.html";
}

function goHome(){

    alert("Returning Home...");

    // Replace later:
    // window.location.href = "index.html";
}